package com.example.damn_news

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
